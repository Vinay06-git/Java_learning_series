import java.util.*;
class freqofOcc{
   public static void main(String[] args){
      int freqOfOcc=0;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the size of an array: ");
      int n=sc.nextInt();
      int[] arr=new int[n];
      System.out.printf("Enter the %dno. of an elements: ",n);
      for(int i=0;i<n;i++){
         arr[i]=sc.nextInt();
      }
      System.out.println("Enter the element to its frequency of occurance: ");
      int Freq=sc.nextInt();
      for(int i=0;i<n;i++){
      if(arr[i]==Freq){
         freqOfOcc++;
      }
      }
      if(freqOfOcc>0){
         System.out.println("Frequecy of occurance of a given element is: " +freqOfOcc);
      }
      else{
         System.out.println("Invalid Element!");
      }
      sc.close();
   }
}